<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title); ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">

                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <p>
                        <h5>Login Aktif : <b><?php echo e(Auth::user()->name); ?></b>, sebagai <b><?php echo e(Auth::user()->role); ?></b>.</h5>
                        </p>
                    </div>
                </div>
                <br>

                <!-- Notifikasi menggunakan flash session data -->
                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                <div class="alert alert-error">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>

                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <h2>DATA POST BERITA</h2>
                        
                        <a href="/logout" class="btn btn-md btn-outline-danger mb-3 float-right" onclick="return confirm('Apakah Anda Yakin Keluar dari sistem ?');">Logout</a>
                        <a href="/create" class="btn btn-md btn-success mb-3 mr-3 float-right">New
                            Post</a>

                        <table class="table table-bordered mt-1">
                            <thead>
                                <tr class="text-center">
                                    <th scope="col">Title</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Create At</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($post->title); ?></td>
                                    <td><?php echo e($post->status == 0 ? 'Draft':'Publish'); ?></td>
                                    <td><?php echo e($post->created_at->format('d-m-Y')); ?></td>
                                    <td class="text-center">
                                        <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                            action="<?php echo e(route('post.destroy', $post->id)); ?>" method="POST">
                                            <a href="<?php echo e(route('post.edit', $post->id)); ?>"
                                                class="btn btn-sm btn-primary">EDIT</a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                                            <button type="submit" class="btn btn-sm btn-danger">HAPUS</button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center text-mute" colspan="4">Data post tidak tersedia</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
<?php /**PATH C:\Users\USER\Documents\Rika Hana UKK 2023\spp_rika\ukk_spp\resources\views/dashboard/index.blade.php ENDPATH**/ ?>