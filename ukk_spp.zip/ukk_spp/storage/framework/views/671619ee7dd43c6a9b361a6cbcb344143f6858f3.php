<?php $__env->startSection('content'); ?>

<div class="breadcrumbs">
    <div class="row justify-content-center">
        <div class="col col-lg-10">
            <div class="card border-0 shadow roundedt">
                <div class="card-body">
                    <p>
                        <h4>Selamat Datang <b><?php echo e(Auth::user()->nama_petugas); ?></b>, Anda Login sebagai <b><?php echo e(Auth::user()->level); ?></b>.</h4>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\Rika Hana UKK 2023\spp_rika\ukk_spp\resources\views/dashboard/dada.blade.php ENDPATH**/ ?>