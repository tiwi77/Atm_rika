<?php $__env->startSection('content'); ?>

<div class="breadcrumbs">
    <div class="row justify-content-center">
        <div class="col-sm-6">
            <div class="page-header float-left">
                <div class="page-title justify-content-center">
                    <h4 class="mt-4 text-center"><b>DAFTAR PETUGAS</b></h4>
                    <br>
                    <a class="btn btn-outline-success" href="/create" role="button">CREATE</a>
                    <?php if(session()->has('success')): ?>
                    <div class="d-flex justify-content-center">
                        <div class="alert alert-success alert-dismissible fade show mb-3" style="width: 18rem;" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    </div>
                    <?php endif; ?>
                    <br>
                    <br>
                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col" class="text-center">NISN</th>
                            <th scope="col" class="text-center">NIS</th>
                            <th scope="col" class="text-center">Nama</th>
                            <th scope="col" class="text-center">Kelas</th>
                            <th scope="col" class="text-center">Alamat</th>
                            <th scope="col" class="text-center">No. telepon</th>
                            <th scope="col" class="text-center">Id SPP</th>
                            <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->level == 'Admin'): ?>
                            <th scope="col" class="text-center">Action</th>
                            <?php endif; ?>
                            <?php endif; ?>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <th scope="row" class="text-center"><?php echo e($index + $siswa->firstItem()); ?></th>
                            <td class="text-center"><?php echo e($item->nisn); ?></td>
                            <td class="text-center"><?php echo e($item->nis); ?></td>
                            <td class="text-center"><?php echo e($item->nama); ?></td>
                            <td class="text-center"><?php echo e($item->id_kelas); ?></td>
                            <td class="text-center"><?php echo e($item->alamat); ?></td>
                            <td class="text-center"><?php echo e($item->no_telp); ?></td>
                            <td class="text-center"><?php echo e($item->id_spp); ?></td>
                            <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->level == 'Admin'): ?>
                            <td class="text-center">
                                <a class="btn trash-petugas" id="<?php echo e($item->nisn); ?>" style="background-color: #FD8A8A" role="button" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="bi bi-trash3"></i></a>
                            </td>
                            </tr>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h4 class="modal-title fs-5" id="exampleModalLabel">Yakin Ingin Menghapus Data Petugas ?</h4>
                                    
                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        
                                    </div>
                                </div>
                                </div>
                            </div>
                        </tbody>
                    </table>
                    <div>
                        <div>
                            Showing Page
                            <?php echo e($siswa->currentPage()); ?>

                            of
                            <?php echo e($siswa->lastPage()); ?>

                        </div>
                        <div class="pull-right">
                            <?php echo e($siswa->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $('.trash-petugas').click(function(){
            const getId = $(this).attr('id')
            $('#button-trash-modal').attr('href', `/dashboard/petugas/delete/${getId}`)
        })
    </script>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\Rika Hana UKK 2023\spp_rika\ukk_spp\resources\views/Dashboard/Siswa/index.blade.php ENDPATH**/ ?>